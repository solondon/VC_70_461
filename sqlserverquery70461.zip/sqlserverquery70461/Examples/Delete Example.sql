
-- DELETE Examples

select * from TestInsert

DELETE FROM TestInsert
WHERE ColA = 7
-- This will delete every row that has a 7 in Column A!
-- Convert DELETE to SELECT * and test

